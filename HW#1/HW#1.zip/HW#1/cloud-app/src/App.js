import React from "react";
import { Analytics } from "@vercel/analytics/react";

function App() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>Hello, Cloud!</h1>
      <p>This is a simple React app deployed on the cloud.</p>
      <Analytics />
    </div>
  );
}

export default App;
